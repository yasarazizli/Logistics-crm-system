import Input from "@/components/Input/Input.tsx";
import { Dispatch, SetStateAction } from "react";

const OrdersTableSearchRow = ({
  data,
  setSearch,
}: {
  data: number[];
  setSearch: Dispatch<
    SetStateAction<{
      id?: string;
      name?: string;
      email?: string;
      phone?: string;
      start_location?: string;
      end_location?: string;
      created?: string;
      status?: string;
      price?: string;
      balance?: string;
      credit?: string;
    }>
  >;
}) => {
  return (
    <tr>
      {/* Id */}
      {data.includes(0) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.id;
                } else {
                  newState.id = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Full name */}
      {data.includes(1) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.name;
                } else {
                  newState.name = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Phone */}
      {data.includes(2) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.phone;
                } else {
                  newState.phone = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Email */}
      {data.includes(3) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.email;
                } else {
                  newState.email = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Start location */}
      {data.includes(4) && (
        <td>
          <span>
            <Input
              style={{
                minWidth: "150px",
              }}
              placeholder={"Search"}
              onChange={(event) => {
                setSearch((prevState) => {
                  const newState = { ...prevState };

                  if (event.target.value === "") {
                    delete newState.start_location;
                  } else {
                    newState.start_location = event.target.value;
                  }

                  return newState;
                });
              }}
            />
          </span>
        </td>
      )}

      {/* End location */}
      {data.includes(5) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.end_location;
                } else {
                  newState.end_location = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Created */}
      {data.includes(6) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.created;
                } else {
                  newState.created = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Status */}
      {data.includes(7) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.status;
                } else {
                  newState.status = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Price */}
      {data.includes(8) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.price;
                } else {
                  newState.price = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Balance */}
      {data.includes(9) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.balance;
                } else {
                  newState.balance = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Credit limit */}
      {data.includes(10) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
            onChange={(event) => {
              setSearch((prevState) => {
                const newState = { ...prevState };

                if (event.target.value === "") {
                  delete newState.credit;
                } else {
                  newState.credit = event.target.value;
                }

                return newState;
              });
            }}
          />
        </td>
      )}

      {/* Out Standing Amount */}
      {data.includes(11) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
          />
        </td>
      )}

      {/* Last Payment Date */}
      {data.includes(12) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
          />
        </td>
      )}

      {/* Commercial Manager */}
      {data.includes(13) && (
        <td>
          <Input
            style={{
              minWidth: "150px",
            }}
            placeholder={"Search"}
          />
        </td>
      )}

      {/* Invoice Document */}
      {data.includes(15) && <td>---</td>}

      {/* User Instruction Document */}
      {data.includes(16) && <td>---</td>}

      {/* User Approve Order */}
      {data.includes(17) && <td>---</td>}

      {/* Order Payment */}
      {data.includes(18) && <td>---</td>}

      {/* Accountant Order Payment Confirmation */}
      {data.includes(19) && <td>---</td>}

      {/* Director Approve Order */}
      {data.includes(20) && <td>----</td>}

      {/* Order Edit */}
      {data.includes(21) && <td>---</td>}
    </tr>
  );
};

export default OrdersTableSearchRow;
